from django.apps import AppConfig


class LoanCalculatorConfig(AppConfig):
    name = 'loan_calculator'
